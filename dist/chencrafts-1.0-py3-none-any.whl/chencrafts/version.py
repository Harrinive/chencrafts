# THIS FILE IS GENERATED FROM chencrafts SETUP.PY
version = '1.0'